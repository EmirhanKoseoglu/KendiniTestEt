﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ScoreCounter : MonoBehaviour
{
	public static ScoreCounter Instance;
	[SerializeField] TMP_Text text;
	public timer1 timer1;
	public int skor1;
	public static int Score { get;  set; }


    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(this);
        }
        else if (this != Instance)
        {
            Destroy(gameObject);
        }
    }
    void Start()
	{
		skor1 = 0;
		Score = 0;
	}
	void OnEnable()
	{
		Target.OnTargetHit += OnTargetHit;
	}
	void Update()
	{
		skor1 = Score;
        //timer1.sonSkor1 = skor1;
    }

	void OnDisable()
	{
		Target.OnTargetHit -= OnTargetHit;
	}

	void OnTargetHit()
	{
		Score++;
		text.text = $"skor: {Score}";
	}
}
