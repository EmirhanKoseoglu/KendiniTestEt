﻿using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour
{

    [SerializeField] TMP_Text timerText;
    public Image image, cross;
    public Text text1,sonSkor;    
    public dogruSecim dogruSecim;
    public GameObject devamEtButton;

    float endTime;
    bool isTimerRunning = true;
    bool isTimeOver = false; // Yalnızca bir kere çağrılacak işlemi izlemek için bayrak

    const float gameTime = 10f;

    void Start()
    {
        endTime = Time.time + gameTime;
        image.enabled = false;
        text1.enabled = false;
        sonSkor.enabled = false;
        devamEtButton.SetActive(false);
    }

    void Update()
    {
        if (isTimerRunning && !isTimeOver)
        {
            float timeLeft = endTime - Time.time;

            if (timeLeft <= 0)
            {
                timeLeft = 0;
                isTimerRunning = false;
                isTimeOver = true; // Zaman bittiğinde işlemi bir kereye mahsus yapmak için bayrağı işaretleyin
                image.enabled = true; // Image'ı görünür yapın
                text1.enabled = true;
                cross.enabled = false;
                Time.timeScale = 0f; // Oyun zamanını durdurur
                sonSkor.text = "Skorunuz: " + dogruSecim.skor.ToString();
                sonSkor.enabled = true;
                devamEtButton.SetActive (true);
            }

            timerText.text = $"Kalan zaman: {timeLeft.ToString("0.0")}";
        }
    }
}
