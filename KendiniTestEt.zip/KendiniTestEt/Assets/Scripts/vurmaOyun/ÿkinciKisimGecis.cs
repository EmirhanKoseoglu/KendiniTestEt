﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class İkinciKisimGecis : MonoBehaviour
{
    public GameObject beyazEkran, oyunBitti, sonSkor, button;
    public string sceneName; // Geçmek istediğiniz sahnenin adı
    public Text countdownText; // Geriye doğru sayım için metin nesnesi
    public float delay = 3f; // Gecikme süresi (3 saniye)
    public AudioClip sesDosyasi;
    private AudioSource sesKaynagi;
    void Start()
    {
        countdownText.enabled = false;
        sesKaynagi = gameObject.AddComponent<AudioSource>();
        sesKaynagi.clip = sesDosyasi;
    }
    void Update()
    {
        
    }

    public void sahneDegis()
    {
        oyunBitti.SetActive(false);
        sonSkor.SetActive(false);
        button.SetActive(false);
        Time.timeScale = 1f;
        StartCoroutine(LoadSceneWithDelay());
    }
    IEnumerator LoadSceneWithDelay()
    {
        countdownText.enabled=true;
        float timeLeft = delay;
        while (timeLeft > 0)
        {
            countdownText.text = Mathf.CeilToInt(timeLeft).ToString(); // Geriye doğru sayımı metin nesnesine yazın
            yield return new WaitForSeconds(1f); // Her saniyede bir güncelle
            timeLeft -= 1f;
            sesKaynagi.Play();
        }

        countdownText.text = ""; // Sayım bittikten sonra metni temizle
        SceneManager.LoadScene("ikinciKisim");
    }

}
