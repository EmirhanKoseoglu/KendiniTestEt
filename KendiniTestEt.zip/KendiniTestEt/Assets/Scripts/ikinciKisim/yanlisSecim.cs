﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class yanlisSecim : MonoBehaviour
{
    public dogruSecim dogruSecim;
    public Button button;
    public islem1 islem1;
    public butonYerDegis butonYerDegis;
    public AudioClip sesDosyasi;
    private AudioSource sesKaynagi;
    // Start is called before the first frame update
    void Start()
    {
        button.onClick.AddListener(ScoreDown);
        sesKaynagi = gameObject.AddComponent<AudioSource>();
        sesKaynagi.clip = sesDosyasi;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void ScoreDown()
    {
        dogruSecim.skor--;
        islem1.islemYapma();
        butonYerDegis.RearrangeButtons();
        sesKaynagi.Play();
    }
}
