﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class butonYerDegis : MonoBehaviour
{
    public Button[] buttons;

    void Start()
    {

    }

    public void RearrangeButtons()
    {
        for (int i = 0; i < buttons.Length; i++)
        {
            int randomIndex = Random.Range(i, buttons.Length);
            // Butonları sadece yatay pozisyonlarını değiştirerek yer değiştir
            Vector2 tempPosition = buttons[i].GetComponent<RectTransform>().anchoredPosition;
            buttons[i].GetComponent<RectTransform>().anchoredPosition = buttons[randomIndex].GetComponent<RectTransform>().anchoredPosition;
            buttons[randomIndex].GetComponent<RectTransform>().anchoredPosition = tempPosition;

            // Butonların kendisini yer değiştirme işlemine gerek yok, sadece pozisyonlarını değiştiriyoruz
        }
    }

    // Space tuşuna basıldığında butonları yeniden düzenle
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            RearrangeButtons();
        }
    }
}
