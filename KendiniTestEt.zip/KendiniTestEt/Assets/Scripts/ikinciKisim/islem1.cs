﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class islem1 : MonoBehaviour
{
    public int[] sayilar = new int[10];
    public string[] islemler = new string[4];
    public string soru;
    public Text text, cevap,a1,b2,c3,d4,e5;
    butonYerDegis butonYerDegis;

    void Start()
    {
        sayilar[0] = 0;
        sayilar[1] = 1;
        sayilar[2] = 2;
        sayilar[3] = 3;
        sayilar[4] = 4;
        sayilar[5] = 5;
        sayilar[6] = 6;
        sayilar[7] = 7;
        sayilar[8] = 8;
        sayilar[9] = 9;

        islemler[0] = "+";
        islemler[1] = "*";
        islemler[2] = "-";
        islemler[3] = "+";
    }
    private void OnSceneLoaded(Scene ikinciKisim, LoadSceneMode mode)
    {
        if (ikinciKisim.name == "ikinciKisim")
        {
            ikiİslem();
        }
    }


    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            islemYapma();
        }
    }


    public void ikiİslem()
    {
        islemYapma();
        butonYerDegis.RearrangeButtons();
    }

    int Hesapla(int sayi1, int sayi2, int sayi3, string islem1, string islem2)
    {
        // Öncelikli işlemi yap
        int sonuc1 = 0;
        if (islem1 == "*" || islem1 == "/")
        {
            sonuc1 = islem1 == "*" ? sayi1 * sayi2 : sayi1 / sayi2;
        }
        else
        {
            sonuc1 = islem1 == "+" ? sayi1 + sayi2 : sayi1 - sayi2;
        }

        // İkinci işlemi yap
        int sonuc2 = 0;
        if (islem2 == "*" || islem2 == "/")
        {
            sonuc2 = islem2 == "*" ? sonuc1 * sayi3 : sonuc1 / sayi3;
        }
        else
        {
            sonuc2 = islem2 == "+" ? sonuc1 + sayi3 : sonuc1 - sayi3;
        }

        return sonuc2;
    }

    public void islemYapma()
    {
        int rastgeleSayi = Random.RandomRange(0, sayilar.Length);
        int rastgeleSayi1 = Random.RandomRange(0, sayilar.Length);
        int rastgeleSayi2 = Random.RandomRange(0, sayilar.Length);

        int rastgeleislem = Random.RandomRange(0, islemler.Length);
        string secilenİslem = islemler[rastgeleislem];
        int rastgeleislem1 = Random.RandomRange(0, islemler.Length);
        string secilenİslem1 = islemler[rastgeleislem1];

        soru = $"{rastgeleSayi} {secilenİslem} {rastgeleSayi1} {secilenİslem1} {rastgeleSayi2}";
        text.text = soru;

        int dogruCevap = Hesapla(rastgeleSayi, rastgeleSayi1, rastgeleSayi2, secilenİslem, secilenİslem1);
        cevap.text = dogruCevap.ToString();
        a1.text = dogruCevap.ToString();
        b2.text = (dogruCevap - 1).ToString();
        c3.text = (dogruCevap - 2).ToString();
        d4.text = (dogruCevap + 1).ToString();
        e5.text = (dogruCevap + 2).ToString();
    }
}
