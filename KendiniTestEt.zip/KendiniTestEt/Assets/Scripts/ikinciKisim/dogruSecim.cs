﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;
using UnityEngine.UI;

public class dogruSecim : MonoBehaviour
{
    public static dogruSecim Instance;
    public Button button;
    public Text text;
    public islem1 islem1;
    public butonYerDegis butonYerDegis;
    public AudioClip sesDosyasi;
    private AudioSource sesKaynagi;

    public static int skor;
    
    void Awake()
    {
        /*if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(this);
        }
        else if (this != Instance)
        {
            Destroy(gameObject);
        }*/
    }
    void Start()
    {
        skor = 0;
        button.onClick.AddListener(ScoreUp);
        sesKaynagi = gameObject.AddComponent<AudioSource>();
        sesKaynagi.clip = sesDosyasi;
    }

    // Update is called once per frame
    void Update()
    {
        text.text = "skor: " + skor.ToString();
    }

    public void OnButtonClick()
    {
        ScoreUp();
        skor--;
        islem1.islemYapma();
        butonYerDegis.RearrangeButtons();
    }

    void ScoreUp()
    {
        skor++; // Skoru artır
        sesKaynagi.Play();
    }
}
