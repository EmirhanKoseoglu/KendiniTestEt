﻿using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class baslama : MonoBehaviour
{
    public GameObject basla, nasil,text,oyunAdi;
    public string sceneName; // Geçmek istediğiniz sahnenin adı
    public Text countdownText; // Geriye doğru sayım için metin nesnesi
    public float delay = 3f; // Gecikme süresi (3 saniye)
    public AudioClip sesDosyasi;
    private AudioSource sesKaynagi;

    void Start()
    {
        countdownText.text = ""; // Başlangıçta metni boş olarak ayarlayın
        text.SetActive(false);
        sesKaynagi = gameObject.AddComponent<AudioSource>();
        sesKaynagi.clip = sesDosyasi;
    }

    public void OnButtonClick()
    {
        text.SetActive(true);
        StartCoroutine(LoadSceneWithDelay());
    }

    IEnumerator LoadSceneWithDelay()
    {
        oyunAdi.SetActive(false);
        basla.SetActive(false);
        nasil.SetActive(false);
        float timeLeft = delay;
        while (timeLeft > 0)
        {
            countdownText.text = Mathf.CeilToInt(timeLeft).ToString(); // Geriye doğru sayımı metin nesnesine yazın
            yield return new WaitForSeconds(1f); // Her saniyede bir güncelle
            timeLeft -= 1f;
            sesKaynagi.Play();
        }

        countdownText.text = ""; // Sayım bittikten sonra metni temizle
        SceneManager.LoadScene(sceneName);
    }
}
