﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SocialPlatforms;
using UnityEngine.UI;

public class sonSkor : MonoBehaviour
{
    public int vurmaSkor, ikinciSkor;
    public Text skor, derece;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        vurmaSkor = ScoreCounter.Instance.skor1;
        ikinciSkor = dogruSecim.skor;
        skor.text ="Skorunuz: " + (vurmaSkor + ikinciSkor).ToString();

        if(vurmaSkor + ikinciSkor <= 20)
        {
            derece.text = "Derece: Kötü";
        }
        if (vurmaSkor + ikinciSkor > 20)
        {
            derece.text = "Derece: Normal";
        }
        if (vurmaSkor + ikinciSkor > 40)
        {
            derece.text = "Derece: İyi";
        }
        if (vurmaSkor + ikinciSkor > 60)
        {
            derece.text = "Derece: Çok İyi";
        }

    }
}
